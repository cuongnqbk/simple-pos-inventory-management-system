
var monthName = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

(function () {
    // "use strict";

    var treeviewMenu = $('.app-menu');

    // Toggle Sidebar
    $('[data-toggle="sidebar"]').click(function(event) {
        event.preventDefault();
        $('.app').toggleClass('sidenav-toggled');
    });

    // Activate sidebar treeview toggle
    $("[data-toggle='treeview']").click(function(event) {
        event.preventDefault();
        if(!$(this).parent().hasClass('is-expanded')) {
            treeviewMenu.find("[data-toggle='treeview']").parent().removeClass('is-expanded');
        }
        $(this).parent().toggleClass('is-expanded');
    });

    // Set initial active toggle
    $("[data-toggle='treeview.'].is-expanded").parent().toggleClass('is-expanded');

    //Activate bootstrip tooltips
    $("[data-toggle='tooltip']").tooltip();

})();


$(function(){
    $( ".forselect2" ).select2({
        theme: "bootstrap4"
    });
});
$(function(){
    var url = window.location.href;
    var activePage = url;
    $('.app-menu a').each(function () {
        var linkPage = this.href;

        if (activePage == linkPage) {
            $(this).addClass("active");
            $(this).parent().parent().closest("ul").parent().addClass('is-expanded');
        }
    });
});


$(function(){
    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true
    });
});

/*$(function(){
    $('.forselect2').select2();
});*/


function formatDate(date){
    var d = new Date(date),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}
$(function(){
    $('.datepicker').change(function(){
        var date = $(this).val();
        $(this).val(formatDate(date));
    });
});

$(function(){
    $('#status').change(function(){
        $('#status_value').val($('#status option:selected').text());
    });
});
$(function(){
    $('.generateRent .datepicker').change(function(){
        var pickedDate = $(this).val();
        var date = new Date(pickedDate);
        var month = date.getMonth();
        var year = date.getFullYear();
        var monthYear = monthName[month]+', '+year;
        $('#rent_month').val(monthYear);
        //alert(monthYear);
    });
});

$(function(){

    /*  */
    $('.transfer #product_id').change(function(){

        if($('#product_id').val() !== 0){
            $('#shop_from_id').removeAttr('disabled', 'disabled');
        }else{
            $('#shop_from_id').attr('disabled', 'disabled');
        }
    });
    $('.transfer #shop_from_id').change(function(){

        if($('#shop_from_id').val() !== 0){
            $('#shop_to_id').removeAttr('disabled', 'disabled');
        }else{
            $('#shop_to_id').attr('disabled', 'disabled');
        }
    });

    $('.transfer #shop_from_id').bind('change', function() {
        var token = $('input[name=_token]').val(); 
        var product_id = $('#product_id').val();
        var shop_from_id = $('#shop_from_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url:  '/admin/productsShopsPostAjax',
            dataType: 'json',
            data: {
                '_token' : token,
                'product_id' : product_id,
                'shop_from_id' : shop_from_id
            },
            success: function(data){ 
                var id = $('#product_id').val();
                var product_id = $('#product_id').val();
                var shop_from_id = $('#shop_from_id').val();
                var index = data.findIndex(x => x.product_id == product_id && x.shop_id == shop_from_id);
                var quantity = data[index].quantity;
                $('#stockQuantityFrom').val(quantity);
            },
            error: function(data) {
                alert(data.responseText);
            }
        });        
    });
    $('.transfer #shop_to_id').bind('change', function() {
        var token = $('input[name=_token]').val(); 
        var product_id = $('#product_id').val();
        var shop_to_id = $('#shop_to_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url:  '/admin/productsShopsPostAjax',
            dataType: 'json',
            data: {
                '_token' : token,
                'product_id' : product_id,
                'shop_to_id' : shop_to_id
            },
            success: function(data){ 
                var product_id = $('#product_id').val();
                var shop_to_id = $('#shop_to_id').val();
                var index = data.findIndex(x => x.product_id == product_id && x.shop_id == shop_to_id);
                var quantity = data[index].quantity;
                $('#stockQuantityTo').val(quantity);
            },
            error: function(data) {
                alert(data.responseText);
            }
        });        
    });
    /*  */
    $('#productBarcode').bind('change', function() {
        var token = $('input[name=_token]').val(); 
        var productBarcode = $('#productBarcode').val();
        var salePrice = $('#salePrice').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url:  '/admin/productsPostAjax',
            dataType: 'json',
            data: {
                '_token' : token,
                'productBarcode' : productBarcode,
                'salePrice' : salePrice
            },
            success: function(data){ 
                console.log(data);
                var id = $('#productBarcode').val();
                var index = data.findIndex(x => x.productBarcode == id);
                var salePrice = data[index].salePrice;
                $('#salePrice').val(salePrice);
            },
            error: function(data) {
                alert(data.responseText);
            }
        });        
    });
    $('.invoiceDetails #client_id').bind('change', function() {
        /*if($(this).val() != 0){
            $('#paidAmount').removeAttr('readonly', 'readonly');

        }else{
            $('#paidAmount').attr('readonly', 'readonly');
        }*/
        var token = $('input[name=_token]').val(); 
        var client_id = $('#client_id').val();
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $.ajax({
            type: "POST",
            url:  '/admin/clientsPostAjax',
            dataType: 'json',
            data: {
                '_token' : token,
                'client_id' : client_id
            },
            success: function(data){ 
                var id = $('#client_id').val();
                var totalBill = Number($('#totalBill').val());
                var discount = Number($('#discount').val());
                var index = data.findIndex(x => x.id == id);
                var contact_no = data[index].contact_no;
                var address = data[index].address;
                var previousDue = data[index].previous_due;
                $('#contact_no').val(contact_no);
                $('#address').val(address);
                $('#previousDue').val(previousDue);
                $('#grandTotal').val(previousDue+totalBill-discount);
            },
            error: function(data) {
                alert(data.responseText);
            }
        });        
    });

    $('#additionalCost').change(function(){
        var subTotal = Number($('#subTotal').val());
        var additionalCost = Number($('#additionalCost').val());
        var discount = Number($('#discount').val());
        // var additionalDiscount = + additionalCost - discount;
        $('#totalBill').val(subTotal + additionalCost);
        var totalBill = Number($('#totalBill').val());
        var previousDue = Number($('#previousDue').val());
        $('#grandTotal').val(totalBill + previousDue  - discount);
    });
    $('#discount').change(function(){   
        var subTotal = Number($('#subTotal').val());     
        var additionalCost = Number($('#additionalCost').val());
        var discount = Number($('#discount').val());
        // var additionalDiscount = additionalCost + discount;
        //$('#totalBill').val(subTotal + additionalCost - discount);
        var totalBill = Number($('#totalBill').val());
        var previousDue = Number($('#previousDue').val());
        $('#grandTotal').val(totalBill + previousDue - discount);
    });
    $('#totalBill').change(function(){
        var totalBill = Number($('#totalBill').val());
        var previousDue = Number($('#previousDue').val());
        $('#grandTotal').val(totalBill + previousDue - discount);
    });
    $('#paidAmount').change(function(){
        var paidAmount = Number($('#paidAmount').val());
        var grandTotal = Number($('#grandTotal').val());
        var previousDue = Number($('#previousDue').val());
        $('#totalDue').val(grandTotal - paidAmount);
    });
    $('#cartSubmit').on("click", function(event){
        event.preventDefault();
        //$('#noItemRow').remove();
        var token = $('input[name=_token]').val(); 
        var productBarcode = $('#productBarcode').val();
        var quantity = $('#quantity').val();
        var special_price = $('#special_price').val();
        $("#quantity_errors").hide();
        $("#quantity_errors").html("");
        $.ajax({
            type: "POST",
            url:  '/admin/cart/addToCart',
            dataType: 'json',
            data: {
                '_token' : token,
                'productBarcode' : productBarcode,
                'quantity' : quantity,
                'special_price' : special_price
            },
            success: function(data){
                if(data.total_quantity > 0){
                    if(data.past_buy === true){
                        console.log(data);
                        var productBarcode = data.productBarcode;
                        var product_id = data.product_id;
                        var name = data.name;
                        var salePrice = Number($('#salePrice').val());
                        var special_price = Number($('#special_price').val());
                        
                        if(!$('#special_price').val()){
                            var price = (+salePrice);
                        }else{
                            price = (+special_price);
                        }
                        var qty = data.quantity;
                        var qtyId="qty"+product_id;
                        var subTotalId="subTotal"+product_id;
                        var oldQty=$("#"+qtyId).val();
                        var oldSubtotal=(+oldQty)*(+price);
                        var subTotal = (+price)*(+qty);

                        var old_totalQty=Number($("#totalItems").val());
                        old_totalQty=(+old_totalQty)+(+qty);
                        old_totalQty=(+old_totalQty)-(+oldQty);
                        $("#totalItems").val(old_totalQty);
                        $("#"+qtyId).val(qty);
                        $("#"+subTotalId).html(subTotal);
                        $("#price"+product_id).html(price);
                        if(old_totalQty>0){
                            $('#noItemRow').hide();
                        }

                        var old_totalPrice=Number($("#subTotal").val().replace(",",""));
                        old_totalPrice=(+old_totalPrice)-(+oldSubtotal);
                        old_totalPrice=(+old_totalPrice)+(+subTotal);
                        $("#subTotal").val(old_totalPrice);
                        $("#totalBill").val(old_totalPrice);
                        $("#grandTotal").val(old_totalPrice);
                        $('#quantity').val(1);
                        $('#productBarcode').val('');
                        $('#productBarcode').attr('autofocus', 'autofocus');
                        $('#special_price').val('');
                        $('#salePrice').val('');
                    }else{
                        console.log(data);
                        var productBarcode = data.productBarcode;
                        var product_id = data.product_id;
                        var name = data.name;
                        var rowId = data.rowid;
                        var salePrice = $('#salePrice').val();
                        var special_price = Number($('#special_price').val());

                        if(!$('#special_price').val()){
                            var price = (+salePrice);
                        }else{
                            price = (+special_price);
                        }
                        var qty = data.quantity;
                        var total_quantity = data.total_quantity;
                        var total_quantityId="qty"+product_id;
                        var subTotalId="subtotal"+product_id;
                        var oldQty=$("#"+qtyId).val();
                        var oldSubtotal=(+oldQty)*(+price);
                        var subTotal = (+price)*(+qty);
                        $('#cartTable').append(`
                            <tr class="animated slideInUp" id="tableRow${product_id}">
                                <td id="name${product_id}">${name}</td>
                                <td style="width:20%;" id="quantity${product_id}">
                                    <div class="input-group">
                                        <input class="form-control form-control-sm" type="text" value="${qty}" id="qty${product_id}" readonly style="width:50px;">
                                        <div class="input-group-btn">
                                            <button type="button" class="btn btn-info btn-custom" onclick="plusQuantity('${rowId}', '${total_quantity}', '${product_id}', '${price}')">
                                                <i class="fas fa-angle-up"></i>
                                            </button>
                                            <button type="button" class="btn btn-info btn-custom" onclick="minusQuantity('${rowId}', '${product_id}','${price}')">
                                                <i class="fas fa-angle-down"></i>
                                            </button>
                                        </div>
                                    </div>
                                </td>
                                <td id="price${product_id}">${price}</td>
                                <td id="subTotal${product_id}">${subTotal}</td>
                                <td id="removeRow${product_id}">
                                    <a onclick="delete_row('${rowId}','${product_id}','${price}')"  class="btn btn-sm btn-default"><i class="fas fa-trash-alt"></i>
                                </td>
                            </tr>
                        `);

                        var old_totalQty=Number($("#totalItems").val());
                        old_totalQty=(+old_totalQty)+(+qty);
                        $("#totalItems").val(old_totalQty);

                        if(old_totalQty>0){
                            $('#noItemRow').hide();
                        }
                        var old_totalPrice=Number($("#subTotal").val().replace(",",""));
                        old_totalPrice=(+old_totalPrice)+(+subTotal);
                        //alert(old_totalPrice);
                        $("#subTotal").val(old_totalPrice);
                        $("#totalBill").val(old_totalPrice);
                        $("#grandTotal").val(old_totalPrice);
                        $('#quantity').val(1);
                        $('#productBarcode').val('');
                        $('#productBarcode').attr('autofocus', 'autofocus');
                        $('#special_price').val('');
                        $('#salePrice').val('');
                    }                
                }else {
                    $("#quantity_errors").show();
                    $("#quantity_errors").html(data.errors);
                }                
            },
            error: function(data) {
                console.log(data.responseText);
            }
        });
    });

});



function delete_row(rowId,id,price){
    var token = $('input[name=_token]').val(); 
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $.ajax({

        type: "POST",
        url:  '/admin/cart/removeItem/'+rowId,
        dataType: 'json',
        data: {
            '_token' : token,
            'rowId': rowId
        },
        success: function(data) {
            console.log(data);
            var qid="qty"+id;
            var input_qty = $("#"+qid).val();
            var sub_total=(+input_qty)*price;
            

            var old_totalQty=$("#totalItems").val();
            old_totalQty=(+old_totalQty)-(+input_qty);
            $("#totalItems").val(old_totalQty);

            if(old_totalQty<1){
                $('#noItemRow').show();
            }
            var old_totalPrice=$("#subTotal").val();
            old_totalPrice=(+old_totalPrice)-(+sub_total);
            $("#subTotal").val(old_totalPrice);
            $("#totalBill").val(old_totalPrice);
            $("#grandTotal").val(old_totalPrice);

            $('#tableRow'+id).remove();
            if(old_totalQty == 0){
                $('#grandTotal').val('');
                $('#additionalCost').val(0);
                $('#discount').val(0);
                $('#previousDue').val(0);
                $('#client_id').val('');
            }
        },
        error: function(data) {
            console.log(data.responseText);
        }
    });
}

function plusQuantity(rowId,total_qty,id,price){    
    var token = $('input[name=_token]').val();           
    var qid="qty"+id;
    var subid="subTotal"+id;
    var input_val = $("#"+qid).val();
    input_val=++input_val;
    var sub_total=input_val*price;

    if(total_qty>=input_val){
        $.ajax({
            type: "POST",
            url: '/admin/cart/increment/'+rowId,
            dataType: 'json',
            data: {
                '_token' : token,
                'rowId': rowId,
                'qty': input_val
            },
            success: function(data) {
                if (data) {
                    if (data.status === true) {
                        console.log(data);
                        $("#"+qid).val(input_val);
                        $("#"+subid).html(sub_total);

                        var old_totalQty=$("#totalItems").val();
                        old_totalQty=++old_totalQty;
                        $("#totalItems").val(old_totalQty);

                        var old_totalPrice=$("#subTotal").val();                        
                        old_totalPrice=(+old_totalPrice)+(+price);
                        $("#subTotal").val(old_totalPrice);
                        $("#totalBill").val(old_totalPrice);
                        $("#grandTotal").val(old_totalPrice);
                    }
                }
            },
            error: function(data) {
                console.log(data.responseText);
            }
        });
        
    }
}
function minusQuantity(rowId,id,price){
    var token = $('input[name=_token]').val();   
    var qid="qty"+id;
    var subid="subTotal"+id;
    var input_val = $("#"+qid).val();
    input_val=--input_val;
    var sub_total=input_val*price;
    if(input_val>0){
        $.ajax({
            type: "POST",
            url: '/admin/cart/decrement/'+rowId,
            dataType: 'json',
            data: {
                '_token' : token,
                'rowId': rowId,
                'qty': input_val
            },
            success: function(data) {
                if (data) {
                    if (data.status === true) {
                        console.log(data);
                        $("#"+qid).val(input_val);
                        $("#"+subid).html(sub_total);
                        var old_totalQty=$("#totalItems").val();
                        old_totalQty=--old_totalQty;
                        $("#totalItems").val(old_totalQty);
                        //* for total price *//
                        var old_totalPrice=$("#subTotal").val();
                        old_totalPrice=(+old_totalPrice)-(+price);
                        $("#subTotal").val(old_totalPrice);
                        $("#totalBill").val(old_totalPrice);
                        $("#grandTotal").val(old_totalPrice);
                    } 
                }
            },
            error: function(data) {
                console.log(data.responseText);
            }
        });
        
    }
}

$(function(){
    $('.addToStock #product_id').change(function(){
        var token = $('input[name=_token]').val(); 
        var product_id = $('#product_id').val();
        if(product_id != 0){
            $('#quantity').removeAttr('readonly', 'readonly');
        }else{
            $('#quantity').attr('readonly', 'readonly');
        }
        $.ajax({
            type: "POST",
            url:  '/admin/productsPostAjax',
            dataType: 'json',
            data: {
                '_token' : token,
                'product_id' : product_id,
            },
            success: function(data){ 
                var id = $('#product_id').val();
                var index = data.findIndex(x => x.id == id);
                var stockQuantity = data[index].stockQuantity;
                var buyPrice = Math.ceil(data[index].buyPrice);
                $('#previous_quantity').val(stockQuantity);
                $('#previous_buyPrice').val(buyPrice);
            }
        });        
    });
    $('.addToStock #quantity').change(function(){

        if($('#quantity').val().length !== 0){
            $('#total_cost').removeAttr('readonly', 'readonly');
        }else{
            $('#total_cost').attr('readonly', 'readonly');
        }

        var new_quantity =   Number($('#quantity').val()) + Number($('#previous_quantity').val());  
        $('#new_quantity').val(new_quantity);
    });
    $('.addToStock #total_cost').change(function(){
        var unit_cost =  Math.ceil(Number($('#total_cost').val()) / Number($('#quantity').val()));  
        var totalBuyPrice = Math.ceil((Number($('#previous_quantity').val())*Number($('#previous_buyPrice').val())) + (Number($('#total_cost').val())));
        var totalQuantity =   Math.ceil(Number($('#quantity').val()) + Number($('#previous_quantity').val()));  
        var buyPrice = Math.ceil(totalBuyPrice/totalQuantity);
        $('#unit_cost').val(unit_cost);
        $('#custom_unit_cost').val(unit_cost);
        $('#buyPrice').val(buyPrice);
    });
});

$(function(){
    /* Receive Payment */
    $('.receivePayment  #client_id').bind('change', function() { 
        var client_id = $('#client_id').val();
        var token = $('input[name=_token]').val();
        $.ajax({
            type: "POST",
            url:  '/admin/clientsPostAjax',
            dataType: 'json',
            data: {
                'client_id' : client_id,
                '_token' : token
            },
            success: function(data) { 
                var id = $('#client_id').val();
                var index = data.findIndex(x => x.id == id);
                var previous_due = data[index].previous_due;
                $('#previous_due').val(previous_due);
            }/*,
            error: function(res) {
                alert('wrong');
                //console.log(res.responseText);
            }*/
        });
    });
    $('#paid_amount').change(function(){
        var previous_due = $('#previous_due').val();
        var paid_amount = $('#paid_amount').val();

        $('#due').val(previous_due - paid_amount);
    });

});

$(function(){
      $('#printSubmit').on("click", function(event){
        event.preventDefault();
        //$('#noItemRow').remove();
        var token = $('input[name=_token]').val(); 
        var product_id = $('#product_id').val();
        var quantity = $('#quantity').val();
        $("#quantity_errors").hide();
        $("#quantity_errors").html("");
        $.ajax({
            type: "POST",
            url:  '/admin/barcode/store',
            dataType: 'json',
            data: {
                '_token' : token,
                'product_id' : product_id,
                'quantity' : quantity
            },
            success: function(data){
                    if(data.past_buy === true){
                        console.log(data);
                        var product_id = data.product_id;
                        var name = data.name;
                        var price = data.price;

                        var qty = +(data.quantity);
                        var qtyId = "quantity"+product_id;
                        var oldQty = +($("#"+qtyId).html());

                        $("#"+qtyId).html(qty);
                        $('#quantity').val(1);
                    }else{
                        console.log(data);
                        var product_id = data.product_id;
                        var name = data.name;
                        var rowId = data.rowid;
                        var price = data.price;


                        var qty = data.quantity;
                        var total_quantityId="quantity"+product_id;
                        var oldQty=Number($("#"+qtyId).html());


                        $('#printTable').append(`
                            <tr class="animated slideInUp" id="tableRow${product_id}">
                                <td id="name${product_id}">${name}</td>
                                <td id="quantity${product_id}">${quantity}</td>
                            </tr>
                        `);

                        // var old_totalQty=Number($("#totalItems").val());
                        // old_totalQty=(+old_totalQty)+(+qty);
                        // $("#totalItems").val(old_totalQty);

                        // if(old_totalQty>0){
                        //     $('#noItemRow').hide();
                        // }

                        $('#quantity').val(1);
                    }                
                /*else {
                    $("#quantity_errors").show();
                    $("#quantity_errors").html(data.errors);
                } */               
            },
            error: function(data) {
                console.log(data.responseText);
            }
        });
    });
});